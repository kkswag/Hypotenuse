package th.ac.su.natnicha.hypotenuse

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var ans = findViewById<TextView>(R.id.ans)
        var a = findViewById<EditText>(R.id.a)
        var b = findViewById<EditText>(R.id.b)


    }
}